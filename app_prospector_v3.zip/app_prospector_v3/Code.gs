/**
 * ============================================================
 *  PROSPECTOR APP - BACKEND (Google Apps Script) — v3
 *  Diogenes Almeida Representações
 * ============================================================
 *  Este script transforma uma planilha Google Sheets em uma
 *  API JSON que o app (PWA) consome via fetch().
 *
 *  ABAS QUE ESTE SCRIPT CRIA/USA AUTOMATICAMENTE:
 *   - LEADS_PROSPECCAO   → leads capturados ao vivo (GPS + Places)
 *   - AGENDA_NOTAS       → anotações/agenda do vendedor
 *   - CLIENTES_BASE      → base completa importada do BigQuery
 *                          (Bondmann + Bransales). Fica toda salva
 *                          aqui, mas só é enviada ao app quando o
 *                          vendedor filtra por cidade/bairro.
 *
 *  ABAS DE ORIGEM PARA IMPORTAÇÃO (você cria/renomeia manualmente):
 *   - IMPORTAR_BONDMANN  → cole aqui o resultado exportado do
 *                          BigQuery para a Bondmann Química
 *   - IMPORTAR_BRANSALES → cole aqui o resultado exportado do
 *                          BigQuery para a Bransales Pneus
 *   (cabeçalhos aceitos, em qualquer ordem: cnpj, razao_social,
 *    nome_fantasia, tipo_logradouro, logradouro, numero, bairro,
 *    cep, municipio, cnae_fiscal_principal, porte, capital_social,
 *    ddd_1, telefone_1, email — exatamente como o BigQuery exporta)
 *
 *  Não precisa criar as abas manualmente: rode a função
 *  "configurarPlanilha" uma vez (veja o passo a passo) e ela
 *  cria tudo com os cabeçalhos certos.
 * ============================================================
 */

const SHEET_LEADS     = 'LEADS_PROSPECCAO';
const SHEET_AGENDA    = 'AGENDA_NOTAS';
const SHEET_CLIENTES  = 'CLIENTES_BASE';

const LEAD_HEADERS = [
  'id', 'data_captura', 'empresa', 'cnpj', 'cnae', 'endereco',
  'telefone', 'email', 'latitude', 'longitude', 'status',
  'origem', 'segmento', 'observacoes', 'vendedor', 'place_id'
];

const AGENDA_HEADERS = [
  'id', 'data', 'hora', 'lead_id', 'titulo', 'nota', 'status'
];

// Base de clientes importada do BigQuery (Bondmann / Bransales)
const CLIENTES_HEADERS = [
  'cnpj', 'razao_social', 'nome_fantasia', 'segmento',
  'tipo_logradouro', 'logradouro', 'numero', 'bairro', 'cep',
  'municipio', 'uf', 'cnae', 'porte', 'capital_social',
  'ddd', 'telefone', 'email',
  'latitude', 'longitude', 'geocodificado',
  'status', 'observacoes', 'vendedor',
  'data_importacao', 'data_atualizacao'
];

// Mapeia os nomes de coluna esperados na planilha exportada do
// BigQuery para os nomes usados internamente na CLIENTES_BASE
const MAPA_IMPORTACAO = {
  cnpj: 'cnpj',
  razao_social: 'razao_social',
  nome_fantasia: 'nome_fantasia',
  tipo_logradouro: 'tipo_logradouro',
  logradouro: 'logradouro',
  numero: 'numero',
  bairro: 'bairro',
  cep: 'cep',
  municipio: 'municipio',
  cnae_fiscal_principal: 'cnae',
  porte: 'porte',
  capital_social: 'capital_social',
  ddd_1: 'ddd',
  telefone_1: 'telefone',
  email: 'email'
};

// Limite de geocodificações feitas em uma única chamada, para não
// estourar o tempo de execução do Apps Script (o serviço Maps
// embutido é gratuito, mas cada chamada leva uma fração de segundo)
const LIMITE_GEOCODE_POR_CHAMADA = 120;

/**
 * Roda esta função UMA VEZ manualmente no editor do Apps Script
 * (selecione "configurarPlanilha" no menu de funções e clique em
 * Executar) para criar as abas e cabeçalhos automaticamente.
 */
function configurarPlanilha() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  criarAbaSeNaoExistir_(ss, SHEET_LEADS, LEAD_HEADERS);
  criarAbaSeNaoExistir_(ss, SHEET_AGENDA, AGENDA_HEADERS);
  criarAbaSeNaoExistir_(ss, SHEET_CLIENTES, CLIENTES_HEADERS);
}

function criarAbaSeNaoExistir_(ss, nome, headers) {
  let sheet = ss.getSheetByName(nome);
  if (!sheet) {
    sheet = ss.insertSheet(nome);
  }
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');
  }
}

/**
 * Menu no Google Sheets, pra rodar a importação sem precisar
 * abrir o editor de script toda vez.
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('📍 Prospector App')
    .addItem('🏗️ Configurar planilha (rodar 1x)', 'configurarPlanilha')
    .addSeparator()
    .addItem('📥 Importar base — Bondmann', 'importarBondmann')
    .addItem('📥 Importar base — Bransales', 'importarBransales')
    .addToUi();
}

function importarBondmann() {
  const r = importarBase_('IMPORTAR_BONDMANN', 'Bondmann');
  SpreadsheetApp.getUi().alert(
    r.ok
      ? '✅ Importação concluída!\n\nNovos: ' + r.importados + '\nJá existiam: ' + r.duplicados + '\nTotal na aba de origem: ' + r.total
      : '❌ Erro: ' + r.erro
  );
}

function importarBransales() {
  const r = importarBase_('IMPORTAR_BRANSALES', 'Bransales');
  SpreadsheetApp.getUi().alert(
    r.ok
      ? '✅ Importação concluída!\n\nNovos: ' + r.importados + '\nJá existiam: ' + r.duplicados + '\nTotal na aba de origem: ' + r.total
      : '❌ Erro: ' + r.erro
  );
}

/**
 * Ponto de entrada para requisições GET
 */
function doGet(e) {
  try {
    const action = e.parameter.action;
    let result;

    switch (action) {
      case 'listLeads':
        result = listarLeads_();
        break;
      case 'listAgenda':
        result = listarAgenda_(e.parameter.data);
        break;
      case 'listRegioes':
        result = listarRegioes_(e.parameter.segmento);
        break;
      case 'listBairros':
        result = listarBairros_(e.parameter.municipio, e.parameter.segmento);
        break;
      case 'listClientesRegiao':
        result = listarClientesRegiao_(e.parameter.municipio, e.parameter.bairro, e.parameter.segmento);
        break;
      case 'ping':
        result = { ok: true, mensagem: 'Backend ativo', hora: new Date().toISOString() };
        break;
      default:
        result = { ok: false, erro: 'Ação GET desconhecida: ' + action };
    }
    return responderJson_(result);
  } catch (err) {
    return responderJson_({ ok: false, erro: err.message });
  }
}

/**
 * Ponto de entrada para requisições POST
 */
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    const payload = body.payload || {};
    let result;

    switch (action) {
      case 'addLead':
        result = adicionarLead_(payload);
        break;
      case 'updateLead':
        result = atualizarLead_(payload);
        break;
      case 'addNote':
        result = adicionarNota_(payload);
        break;
      case 'updateNote':
        result = atualizarNota_(payload);
        break;
      case 'updateCliente':
        result = atualizarCliente_(payload);
        break;
      case 'importarBase':
        result = importarBase_(
          payload.segmento === 'Bondmann' ? 'IMPORTAR_BONDMANN' : 'IMPORTAR_BRANSALES',
          payload.segmento
        );
        break;
      default:
        result = { ok: false, erro: 'Ação POST desconhecida: ' + action };
    }
    return responderJson_(result);
  } catch (err) {
    return responderJson_({ ok: false, erro: err.message });
  }
}

function responderJson_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function getSheet_(nome) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(nome);
  if (!sheet) throw new Error('Aba "' + nome + '" não existe. Rode configurarPlanilha() primeiro.');
  return sheet;
}

function linhaParaObjeto_(headers, linha) {
  const obj = {};
  headers.forEach((h, i) => { obj[h] = linha[i]; });
  return obj;
}

/* ================================================================
   LEADS (capturados ao vivo por GPS/Places — não mexi nesta parte)
   ================================================================ */

function listarLeads_() {
  const sheet = getSheet_(SHEET_LEADS);
  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  const leads = dados
    .filter(linha => linha[0] !== '')
    .map(linha => linhaParaObjeto_(headers, linha));
  return { ok: true, leads };
}

function adicionarLead_(payload) {
  const sheet = getSheet_(SHEET_LEADS);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colPlaceId = headers.indexOf('place_id');
  const colCnpj = headers.indexOf('cnpj');

  for (let i = 1; i < dados.length; i++) {
    const placeIdIgual = payload.place_id && dados[i][colPlaceId] === payload.place_id;
    const cnpjIgual = payload.cnpj && dados[i][colCnpj] === payload.cnpj;
    if (placeIdIgual || cnpjIgual) {
      return { ok: true, duplicado: true, id: dados[i][0], mensagem: 'Lead já existia, não duplicado.' };
    }
  }

  const id = Utilities.getUuid();
  const novaLinha = LEAD_HEADERS.map(h => {
    if (h === 'id') return id;
    if (h === 'data_captura') return new Date().toISOString();
    if (h === 'status') return payload.status || 'novo';
    return payload[h] !== undefined ? payload[h] : '';
  });
  sheet.appendRow(novaLinha);
  return { ok: true, id };
}

function atualizarLead_(payload) {
  if (!payload.id) return { ok: false, erro: 'id é obrigatório para atualizar lead' };
  const sheet = getSheet_(SHEET_LEADS);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colId = headers.indexOf('id');

  for (let i = 1; i < dados.length; i++) {
    if (dados[i][colId] === payload.id) {
      headers.forEach((h, idx) => {
        if (h !== 'id' && payload[h] !== undefined) {
          sheet.getRange(i + 1, idx + 1).setValue(payload[h]);
        }
      });
      return { ok: true };
    }
  }
  return { ok: false, erro: 'Lead não encontrado: ' + payload.id };
}

/* ---------------- AGENDA / NOTAS (sem alterações) ---------------- */

function listarAgenda_(dataFiltro) {
  const sheet = getSheet_(SHEET_AGENDA);
  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  let itens = dados
    .filter(linha => linha[0] !== '')
    .map(linha => linhaParaObjeto_(headers, linha));
  if (dataFiltro) {
    itens = itens.filter(item => item.data === dataFiltro);
  }
  return { ok: true, itens };
}

function adicionarNota_(payload) {
  const sheet = getSheet_(SHEET_AGENDA);
  const id = Utilities.getUuid();
  const agora = new Date();
  const novaLinha = AGENDA_HEADERS.map(h => {
    if (h === 'id') return id;
    if (h === 'data') return payload.data || Utilities.formatDate(agora, Session.getScriptTimeZone(), 'yyyy-MM-dd');
    if (h === 'hora') return payload.hora || Utilities.formatDate(agora, Session.getScriptTimeZone(), 'HH:mm');
    if (h === 'status') return payload.status || 'pendente';
    return payload[h] !== undefined ? payload[h] : '';
  });
  sheet.appendRow(novaLinha);
  return { ok: true, id };
}

function atualizarNota_(payload) {
  if (!payload.id) return { ok: false, erro: 'id é obrigatório para atualizar nota' };
  const sheet = getSheet_(SHEET_AGENDA);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colId = headers.indexOf('id');

  for (let i = 1; i < dados.length; i++) {
    if (dados[i][colId] === payload.id) {
      headers.forEach((h, idx) => {
        if (h !== 'id' && payload[h] !== undefined) {
          sheet.getRange(i + 1, idx + 1).setValue(payload[h]);
        }
      });
      return { ok: true };
    }
  }
  return { ok: false, erro: 'Nota não encontrada: ' + payload.id };
}

/* ================================================================
   CLIENTES_BASE — importação em massa do BigQuery
   ================================================================ */

/**
 * Lê a aba de origem (IMPORTAR_BONDMANN ou IMPORTAR_BRANSALES),
 * reconhece as colunas pelo nome do cabeçalho (não importa a ordem),
 * e adiciona à CLIENTES_BASE apenas os CNPJs que ainda não existem.
 * Roda tudo em memória com leitura/escrita em lote, então dá conta
 * de dezenas de milhares de linhas numa execução só.
 */
function importarBase_(nomeAbaOrigem, segmento) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const origem = ss.getSheetByName(nomeAbaOrigem);
  if (!origem) {
    return { ok: false, erro: 'Aba "' + nomeAbaOrigem + '" não encontrada. Cole ali o resultado exportado do BigQuery (com cabeçalho na linha 1) antes de importar.' };
  }

  const dadosOrigem = origem.getDataRange().getValues();
  if (dadosOrigem.length < 2) {
    return { ok: false, erro: 'A aba "' + nomeAbaOrigem + '" está vazia.' };
  }

  const headersOrigem = dadosOrigem[0].map(h => h.toString().trim());
  const idxOrigem = {};
  headersOrigem.forEach((h, i) => {
    const destino = MAPA_IMPORTACAO[h];
    if (destino) idxOrigem[destino] = i;
  });
  if (idxOrigem.cnpj === undefined) {
    return { ok: false, erro: 'Não encontrei a coluna "cnpj" na aba "' + nomeAbaOrigem + '". Confira se o cabeçalho está igual ao exportado pelo BigQuery.' };
  }

  criarAbaSeNaoExistir_(ss, SHEET_CLIENTES, CLIENTES_HEADERS);
  const destinoSheet = getSheet_(SHEET_CLIENTES);
  const dadosDestino = destinoSheet.getDataRange().getValues();
  const headersDestino = dadosDestino.length ? dadosDestino[0] : CLIENTES_HEADERS;
  const colCnpjDestino = headersDestino.indexOf('cnpj');

  const cnpjsExistentes = new Set();
  for (let i = 1; i < dadosDestino.length; i++) {
    const c = dadosDestino[i][colCnpjDestino];
    if (c) cnpjsExistentes.add(c.toString().replace(/\D/g, ''));
  }

  const agora = new Date().toISOString();
  const novasLinhas = [];
  let duplicados = 0;

  for (let i = 1; i < dadosOrigem.length; i++) {
    const linha = dadosOrigem[i];
    const cnpjRaw = (linha[idxOrigem.cnpj] || '').toString().replace(/\D/g, '');
    if (!cnpjRaw) continue;
    if (cnpjsExistentes.has(cnpjRaw)) { duplicados++; continue; }
    cnpjsExistentes.add(cnpjRaw);

    const linhaNova = CLIENTES_HEADERS.map(h => {
      if (h === 'cnpj') return cnpjRaw;
      if (h === 'segmento') return segmento;
      if (h === 'latitude' || h === 'longitude') return '';
      if (h === 'geocodificado') return 'nao';
      if (h === 'status') return 'novo';
      if (h === 'observacoes') return '';
      if (h === 'vendedor') return '';
      if (h === 'data_importacao') return agora;
      if (h === 'data_atualizacao') return agora;
      const origemIdx = idxOrigem[h];
      return origemIdx !== undefined ? linha[origemIdx] : '';
    });
    novasLinhas.push(linhaNova);
  }

  if (novasLinhas.length > 0) {
    destinoSheet.getRange(destinoSheet.getLastRow() + 1, 1, novasLinhas.length, CLIENTES_HEADERS.length)
      .setValues(novasLinhas);
  }

  return {
    ok: true,
    importados: novasLinhas.length,
    duplicados,
    total: dadosOrigem.length - 1
  };
}

/**
 * Lista as cidades (municípios) presentes na base, com contagem —
 * usado para popular o filtro de região no app, sem carregar os
 * clientes em si.
 */
function listarRegioes_(segmento) {
  const sheet = getSheet_(SHEET_CLIENTES);
  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  const colMunicipio = headers.indexOf('municipio');
  const colSegmento = headers.indexOf('segmento');

  const contagem = {};
  dados.forEach(linha => {
    if (!linha[0]) return;
    if (segmento && segmento !== 'Todos' && linha[colSegmento] !== segmento) return;
    const mun = (linha[colMunicipio] || '(sem cidade)').toString();
    contagem[mun] = (contagem[mun] || 0) + 1;
  });

  const regioes = Object.keys(contagem)
    .sort()
    .map(m => ({ municipio: m, total: contagem[m] }));

  return { ok: true, regioes };
}

/**
 * Lista os bairros de um município específico, com contagem.
 */
function listarBairros_(municipio, segmento) {
  if (!municipio) return { ok: false, erro: 'Informe o município.' };
  const sheet = getSheet_(SHEET_CLIENTES);
  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  const colMunicipio = headers.indexOf('municipio');
  const colBairro = headers.indexOf('bairro');
  const colSegmento = headers.indexOf('segmento');

  const contagem = {};
  dados.forEach(linha => {
    if (!linha[0]) return;
    if (linha[colMunicipio] !== municipio) return;
    if (segmento && segmento !== 'Todos' && linha[colSegmento] !== segmento) return;
    const b = (linha[colBairro] || '(sem bairro)').toString();
    contagem[b] = (contagem[b] || 0) + 1;
  });

  const bairros = Object.keys(contagem)
    .sort()
    .map(b => ({ bairro: b, total: contagem[b] }));

  return { ok: true, bairros };
}

/**
 * Retorna os clientes de uma região (cidade, e opcionalmente bairro).
 * Geocodifica sob demanda (só os que ainda não têm lat/lng) usando o
 * serviço de mapas gratuito e embutido do Apps Script, e salva o
 * resultado de volta na planilha para não precisar geocodificar de
 * novo da próxima vez.
 *
 * Se a região tiver mais endereços sem coordenada do que o limite por
 * chamada, retorna parcial=true — o app pode chamar de novo (ou pedir
 * pro vendedor filtrar por bairro também) para completar aos poucos.
 */
function listarClientesRegiao_(municipio, bairro, segmento) {
  if (!municipio) return { ok: false, erro: 'Informe o município.' };
  const sheet = getSheet_(SHEET_CLIENTES);
  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  const idx = {};
  headers.forEach((h, i) => idx[h] = i);

  const linhasFiltradas = [];
  dados.forEach((linha, i) => {
    if (!linha[idx.cnpj]) return;
    if (linha[idx.municipio] !== municipio) return;
    if (bairro && linha[idx.bairro] !== bairro) return;
    if (segmento && segmento !== 'Todos' && linha[idx.segmento] !== segmento) return;
    linhasFiltradas.push({ linhaPlanilha: i + 2, valores: linha }); // +2 = +1 cabeçalho +1 índice base 1
  });

  let geocodificadosNestaChamada = 0;
  let restantes = 0;

  for (let i = 0; i < linhasFiltradas.length; i++) {
    const item = linhasFiltradas[i];
    const jaTem = item.valores[idx.latitude] && item.valores[idx.longitude];
    if (jaTem) continue;

    if (geocodificadosNestaChamada >= LIMITE_GEOCODE_POR_CHAMADA) {
      restantes++;
      continue;
    }

    const endereco = montarEnderecoCompleto_(item.valores, idx);
    const coord = geocodificarEndereco_(endereco);
    geocodificadosNestaChamada++;

    if (coord) {
      item.valores[idx.latitude] = coord.lat;
      item.valores[idx.longitude] = coord.lng;
      item.valores[idx.geocodificado] = 'sim';
      sheet.getRange(item.linhaPlanilha, idx.latitude + 1, 1, 3)
        .setValues([[coord.lat, coord.lng, 'sim']]);
    } else {
      item.valores[idx.geocodificado] = 'falhou';
      sheet.getRange(item.linhaPlanilha, idx.geocodificado + 1).setValue('falhou');
    }
  }

  const clientes = linhasFiltradas
    .map(item => linhaParaObjeto_(headers, item.valores))
    .filter(c => c.latitude && c.longitude);

  return {
    ok: true,
    clientes,
    total_regiao: linhasFiltradas.length,
    exibidos_no_mapa: clientes.length,
    parcial: restantes > 0,
    restantes
  };
}

function montarEnderecoCompleto_(linha, idx) {
  const partes = [
    linha[idx.tipo_logradouro], linha[idx.logradouro], linha[idx.numero],
    linha[idx.bairro], linha[idx.municipio], 'SC', 'Brasil'
  ];
  return partes.filter(Boolean).join(' ');
}

function geocodificarEndereco_(endereco) {
  try {
    const geocoder = Maps.newGeocoder().setRegion('br');
    const resposta = geocoder.geocode(endereco);
    if (resposta.status === 'OK' && resposta.results.length > 0) {
      const loc = resposta.results[0].geometry.location;
      return { lat: loc.lat, lng: loc.lng };
    }
    return null;
  } catch (err) {
    return null;
  }
}

function atualizarCliente_(payload) {
  if (!payload.cnpj) return { ok: false, erro: 'cnpj é obrigatório para atualizar cliente' };
  const sheet = getSheet_(SHEET_CLIENTES);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colCnpj = headers.indexOf('cnpj');

  for (let i = 1; i < dados.length; i++) {
    if (dados[i][colCnpj] === payload.cnpj) {
      headers.forEach((h, idx) => {
        if (h === 'cnpj') return;
        if (h === 'data_atualizacao') {
          sheet.getRange(i + 1, idx + 1).setValue(new Date().toISOString());
          return;
        }
        if (payload[h] !== undefined) {
          sheet.getRange(i + 1, idx + 1).setValue(payload[h]);
        }
      });
      return { ok: true };
    }
  }
  return { ok: false, erro: 'Cliente não encontrado: ' + payload.cnpj };
}
