/**
 * ============================================================
 *  PROSPECTOR — BACKEND (Google Apps Script)
 *  Diogenes Almeida Representações
 * ============================================================
 *  Este script mantém o contrato original do app (listLeads,
 *  listAgenda, addLead, updateLead, addNote, updateNote, ping)
 *  e ACRESCENTA o que faltava para a Base de Clientes por região:
 *   - listRegioes, listBairros, listClientesRegiao (GET)
 *   - importarBase (POST) — lê as abas IMPORTAR_BONDMANN /
 *     IMPORTAR_BRANSALES (colar aqui o resultado do BigQuery) e
 *     joga pra dentro da aba BASE_CLIENTES, sem duplicar por CNPJ.
 *
 *  A geocodificação (endereço → lat/lng) acontece aos poucos,
 *  sob demanda, quando você escolhe uma cidade na Base de
 *  Clientes — não trava a importação nem estoura o limite de
 *  6 minutos de execução do Apps Script.
 *
 *  Rode "configurarPlanilha" uma vez (ou de novo, é seguro
 *  repetir) depois de colar este código.
 * ============================================================
 */

const SHEET_LEADS = 'Clientes';
const SHEET_LEADS_ANTIGA = 'LEADS_PROSPECCAO'; // nome usado antes de renomear
const SHEET_AGENDA = 'AGENDA_NOTAS';
const SHEET_BASE = 'BASE_CLIENTES';
const SHEET_IMPORT_BONDMANN = 'IMPORTAR_BONDMANN';
const SHEET_IMPORT_BRANSALES = 'IMPORTAR_BRANSALES';

const LEAD_HEADERS = [
  'id', 'data_captura', 'empresa', 'cnpj', 'cnae', 'endereco',
  'telefone', 'email', 'latitude', 'longitude', 'status',
  'origem', 'segmento', 'contato', 'observacoes', 'vendedor', 'place_id'
];
const AGENDA_HEADERS = ['id', 'data', 'hora', 'lead_id', 'titulo', 'nota', 'status'];
const BASE_HEADERS = [
  'cnpj', 'razao_social', 'nome_fantasia', 'segmento', 'municipio', 'bairro',
  'endereco', 'cep', 'cnae', 'porte', 'capital_social', 'contato', 'latitude', 'longitude', 'geocoded'
];
const CHECKIN_HEADERS = ['timestamp', 'cnpj', 'nome_cliente', 'tipo_origem', 'latitude', 'longitude', 'status_definido', 'observacoes', 'vendedor'];
const SHEET_CHECKINS = 'Checkins';

/* ============================================================
   MENU NA PLANILHA (corrige o erro "Função de script não
   encontrada: importarBondmann" que aparecia num botão/atalho)
   ============================================================ */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Prospector CRM')
    .addItem('Configurar planilha', 'configurarPlanilha')
    .addSeparator()
    .addItem('Importar base Bondmann', 'importarBondmann')
    .addItem('Importar base Bransales', 'importarBransales')
    .addToUi();
}
function importarBondmann() { rodarImportacaoComAlerta_('Bondmann'); }
function importarBransales() { rodarImportacaoComAlerta_('Bransales'); }
function rodarImportacaoComAlerta_(segmento) {
  const r = importarBase_({ segmento });
  const msg = r.ok ? ('Importados: ' + r.importados + ' · Já existiam: ' + r.duplicados) : ('Erro: ' + r.erro);
  SpreadsheetApp.getUi().alert(msg);
}

/* ============================================================
   ENDPOINTS
   ============================================================ */

function doGet(e) {
  try {
    const action = e.parameter.action;
    let result;
    switch (action) {
      case 'ping':
        result = { ok: true, mensagem: 'Backend ativo', hora: new Date().toISOString() };
        break;
      case 'listLeads':
        result = listarLeads_();
        break;
      case 'listAgenda':
        result = listarAgenda_(e.parameter.data);
        break;
      case 'listRegioes':
        result = listarRegioes_(e.parameter.segmento, e.parameter.cnae);
        break;
      case 'listBairros':
        result = listarBairros_(e.parameter.municipio, e.parameter.segmento, e.parameter.cnae);
        break;
      case 'listClientesRegiao':
        result = listarClientesRegiao_(e.parameter.municipio, e.parameter.bairro, e.parameter.segmento, e.parameter.cnae);
        break;
      case 'listRamos':
        result = listarRamos_(e.parameter.segmento);
        break;
      default:
        result = { ok: false, erro: 'Ação GET desconhecida: ' + action };
    }
    return responderJson_(result);
  } catch (err) {
    return responderJson_({ ok: false, erro: err.message });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    const payload = body.payload || {};
    let result;
    switch (action) {
      case 'addLead':
        result = adicionarLead_(payload);
        break;
      case 'updateLead':
        result = atualizarLead_(payload);
        break;
      case 'addNote':
        result = adicionarNota_(payload);
        break;
      case 'updateNote':
        result = atualizarNota_(payload);
        break;
      case 'importarBase':
        result = importarBase_(payload);
        break;
      case 'updateCliente':
        result = atualizarCliente_(payload);
        break;
      case 'logVisita':
        result = registrarCheckin_(payload);
        break;
      default:
        result = { ok: false, erro: 'Ação POST desconhecida: ' + action };
    }
    return responderJson_(result);
  } catch (err) {
    return responderJson_({ ok: false, erro: err.message });
  }
}

function responderJson_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function getSheet_(nome) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(nome);
  if (!sheet) throw new Error('Aba "' + nome + '" não existe. Rode configurarPlanilha() primeiro.');
  return sheet;
}
function sh_(nome) { return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nome); }

// Acrescenta ao final colunas que ainda não existem na aba, sem mexer
// nas colunas/dados que já estão lá.
function ensureHeaders_(sheet, desejados) {
  const lastCol = sheet.getLastColumn();
  const existentes = lastCol > 0 ? sheet.getRange(1, 1, 1, lastCol).getValues()[0] : [];
  desejados.forEach(h => {
    if (existentes.indexOf(h) === -1) {
      sheet.getRange(1, sheet.getLastColumn() + 1).setValue(h);
      existentes.push(h);
    }
  });
}

function linhaParaObjeto_(headers, linha) {
  const obj = {};
  headers.forEach((h, i) => { obj[h] = linha[i]; });
  return obj;
}

/* ---------------- LEADS / CLIENTES ---------------- */

function listarLeads_() {
  const sheet = getSheet_(SHEET_LEADS);
  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  const leads = dados.filter(l => l[0] !== '').map(l => linhaParaObjeto_(headers, l));
  return { ok: true, leads };
}

function adicionarLead_(payload) {
  const sheet = getSheet_(SHEET_LEADS);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colPlaceId = headers.indexOf('place_id');
  const colCnpj = headers.indexOf('cnpj');

  for (let i = 1; i < dados.length; i++) {
    const placeIdIgual = payload.place_id && dados[i][colPlaceId] === payload.place_id;
    const cnpjIgual = payload.cnpj && dados[i][colCnpj] === payload.cnpj;
    if (placeIdIgual || cnpjIgual) {
      return { ok: true, duplicado: true, id: dados[i][headers.indexOf('id')], mensagem: 'Lead já existia, não duplicado.' };
    }
  }

  const id = Utilities.getUuid();
  const novaLinha = headers.map(h => {
    if (h === 'id') return id;
    if (h === 'data_captura') return new Date().toISOString();
    if (h === 'status') return payload.status || 'novo';
    return payload[h] !== undefined ? payload[h] : '';
  });
  sheet.appendRow(novaLinha);
  return { ok: true, id };
}

function atualizarLead_(payload) {
  if (!payload.id) return { ok: false, erro: 'id é obrigatório para atualizar lead' };
  const sheet = getSheet_(SHEET_LEADS);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colId = headers.indexOf('id');

  for (let i = 1; i < dados.length; i++) {
    if (dados[i][colId] === payload.id) {
      headers.forEach((h, idx) => {
        if (h !== 'id' && payload[h] !== undefined) sheet.getRange(i + 1, idx + 1).setValue(payload[h]);
      });
      return { ok: true };
    }
  }
  return { ok: false, erro: 'Lead não encontrado: ' + payload.id };
}

/* ---------------- AGENDA / NOTAS ---------------- */

function listarAgenda_(dataFiltro) {
  const sheet = getSheet_(SHEET_AGENDA);
  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  let itens = dados.filter(l => l[0] !== '').map(l => linhaParaObjeto_(headers, l));
  if (dataFiltro) itens = itens.filter(item => item.data === dataFiltro);
  return { ok: true, itens };
}

function adicionarNota_(payload) {
  const sheet = getSheet_(SHEET_AGENDA);
  const id = Utilities.getUuid();
  const agora = new Date();
  const novaLinha = AGENDA_HEADERS.map(h => {
    if (h === 'id') return id;
    if (h === 'data') return payload.data || Utilities.formatDate(agora, Session.getScriptTimeZone(), 'yyyy-MM-dd');
    if (h === 'hora') return payload.hora || Utilities.formatDate(agora, Session.getScriptTimeZone(), 'HH:mm');
    if (h === 'status') return payload.status || 'pendente';
    return payload[h] !== undefined ? payload[h] : '';
  });
  sheet.appendRow(novaLinha);
  return { ok: true, id };
}

function atualizarNota_(payload) {
  if (!payload.id) return { ok: false, erro: 'id é obrigatório para atualizar nota' };
  const sheet = getSheet_(SHEET_AGENDA);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colId = headers.indexOf('id');
  for (let i = 1; i < dados.length; i++) {
    if (dados[i][colId] === payload.id) {
      headers.forEach((h, idx) => {
        if (h !== 'id' && payload[h] !== undefined) sheet.getRange(i + 1, idx + 1).setValue(payload[h]);
      });
      return { ok: true };
    }
  }
  return { ok: false, erro: 'Nota não encontrada: ' + payload.id };
}

/* ============================================================
   BASE DE CLIENTES (importação BigQuery + busca por região)
   ============================================================ */

function importarBase_(payload) {
  const segmento = payload.segmento;
  if (segmento !== 'Bondmann' && segmento !== 'Bransales') {
    return { ok: false, erro: 'segmento precisa ser "Bondmann" ou "Bransales"' };
  }
  const nomeOrigem = segmento === 'Bondmann' ? SHEET_IMPORT_BONDMANN : SHEET_IMPORT_BRANSALES;
  const origem = sh_(nomeOrigem);
  if (!origem) return { ok: false, erro: 'Aba "' + nomeOrigem + '" não encontrada. Cole o resultado do BigQuery nela antes de importar.' };

  const dadosOrigem = origem.getDataRange().getValues();
  if (dadosOrigem.length < 2) return { ok: false, erro: 'Aba "' + nomeOrigem + '" está vazia.' };
  const headersOrigem = dadosOrigem.shift().map(h => String(h).trim());
  const idx = {};
  headersOrigem.forEach((h, i) => { idx[h] = i; });
  const col = (nomes) => { for (const n of nomes) if (idx[n] !== undefined) return idx[n]; return -1; };

  const cCnpj = col(['cnpj']);
  const cRazao = col(['razao_social']);
  const cFantasia = col(['nome_fantasia']);
  const cTipoLog = col(['tipo_logradouro']);
  const cLog = col(['logradouro']);
  const cNumero = col(['numero']);
  const cBairro = col(['bairro']);
  const cCep = col(['cep']);
  const cMunicipio = col(['municipio']);
  const cCnae = col(['cnae_fiscal_principal', 'cnae']);
  const cPorte = col(['porte']);
  const cCapital = col(['capital_social', 'capital_soc']);

  if (cCnpj === -1 || cMunicipio === -1) {
    return { ok: false, erro: 'A aba "' + nomeOrigem + '" precisa ter pelo menos as colunas cnpj e municipio.' };
  }

  const baseSheet = getOrCriarBase_();
  const dadosBase = baseSheet.getDataRange().getValues();
  const headersBase = dadosBase.shift();
  const colCnpjBase = headersBase.indexOf('cnpj');
  const cnpjsExistentes = new Set(dadosBase.map(l => String(l[colCnpjBase]).trim()));

  let importados = 0, duplicados = 0;
  const novasLinhas = [];
  dadosOrigem.forEach(linha => {
    const cnpj = String(linha[cCnpj] || '').trim();
    if (!cnpj) return;
    if (cnpjsExistentes.has(cnpj)) { duplicados++; return; }
    cnpjsExistentes.add(cnpj);
    const endereco = [
      cTipoLog >= 0 ? linha[cTipoLog] : '',
      cLog >= 0 ? linha[cLog] : '',
      cNumero >= 0 ? linha[cNumero] : ''
    ].filter(Boolean).join(' ');
    novasLinhas.push([
      cnpj,
      cRazao >= 0 ? linha[cRazao] : '',
      cFantasia >= 0 ? linha[cFantasia] : '',
      segmento,
      cMunicipio >= 0 ? linha[cMunicipio] : '',
      cBairro >= 0 ? linha[cBairro] : '',
      endereco,
      cCep >= 0 ? linha[cCep] : '',
      cCnae >= 0 ? linha[cCnae] : '',
      cPorte >= 0 ? linha[cPorte] : '',
      cCapital >= 0 ? linha[cCapital] : '',
      '', '', false
    ]);
    importados++;
  });

  if (novasLinhas.length) {
    baseSheet.getRange(baseSheet.getLastRow() + 1, 1, novasLinhas.length, BASE_HEADERS.length).setValues(novasLinhas);
  }
  return { ok: true, importados, duplicados };
}

// Atualiza um registro da Base de Clientes (importados do BigQuery) pelo CNPJ
function atualizarCliente_(payload) {
  if (!payload.cnpj) return { ok: false, erro: 'cnpj é obrigatório para atualizar cliente' };
  const sheet = sh_(SHEET_BASE);
  if (!sheet) return { ok: false, erro: 'Base de clientes ainda não existe' };
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colCnpj = headers.indexOf('cnpj');
  for (let i = 1; i < dados.length; i++) {
    if (String(dados[i][colCnpj]).trim() === String(payload.cnpj).trim()) {
      headers.forEach((h, idx) => {
        if (h !== 'cnpj' && payload[h] !== undefined && payload[h] !== '') {
          sheet.getRange(i + 1, idx + 1).setValue(payload[h]);
        }
      });
      return { ok: true };
    }
  }
  return { ok: false, erro: 'Cliente não encontrado na base: ' + payload.cnpj };
}

// Registra a chegada/checkin numa visita da rota do dia
function registrarCheckin_(payload) {
  let sheet = sh_(SHEET_CHECKINS);
  if (!sheet) {
    sheet = SpreadsheetApp.getActiveSpreadsheet().insertSheet(SHEET_CHECKINS);
    sheet.appendRow(CHECKIN_HEADERS);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, CHECKIN_HEADERS.length).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');
  }
  sheet.appendRow(CHECKIN_HEADERS.map(h => {
    if (h === 'timestamp') return new Date().toISOString();
    return payload[h] !== undefined ? payload[h] : '';
  }));
  return { ok: true };
}

function getOrCriarBase_() {
  let s = sh_(SHEET_BASE);
  if (!s) {
    s = SpreadsheetApp.getActiveSpreadsheet().insertSheet(SHEET_BASE);
    s.appendRow(BASE_HEADERS);
    s.setFrozenRows(1);
    s.getRange(1, 1, 1, BASE_HEADERS.length).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');
  }
  return s;
}

function aplicarFiltrosBase_(rows, segmento, cnae) {
  let out = rows;
  if (segmento && segmento !== 'Todos') out = out.filter(r => r.segmento === segmento);
  if (cnae) out = out.filter(r => String(r.cnae || '').trim() === String(cnae).trim());
  return out;
}

function listarRegioes_(segmento, cnae) {
  const filtradas = aplicarFiltrosBase_(lerBase_(), segmento, cnae);
  const counts = {};
  filtradas.forEach(r => {
    const m = (r.municipio || '').trim() || '(sem cidade)';
    counts[m] = (counts[m] || 0) + 1;
  });
  const regioes = Object.keys(counts).map(m => ({ municipio: m, total: counts[m] })).sort((a, b) => b.total - a.total);
  return { ok: true, regioes };
}

function listarBairros_(municipio, segmento, cnae) {
  const rows = lerBase_().filter(r => r.municipio === municipio);
  const filtradas = aplicarFiltrosBase_(rows, segmento, cnae);
  const counts = {};
  filtradas.forEach(r => {
    const b = (r.bairro || '').trim() || '(sem bairro)';
    counts[b] = (counts[b] || 0) + 1;
  });
  const bairros = Object.keys(counts).map(b => ({ bairro: b, total: counts[b] })).sort((a, b) => b.total - a.total);
  return { ok: true, bairros };
}

// Lista os CNAEs distintos presentes no segmento — vira o filtro "Ramo".
// Mostra o código do CNAE (a base do BigQuery não traz descrição por
// extenso); ordenado do mais frequente para o menos frequente.
function listarRamos_(segmento) {
  const filtradas = aplicarFiltrosBase_(lerBase_(), segmento, null);
  const counts = {};
  filtradas.forEach(r => {
    const c = String(r.cnae || '').trim();
    if (!c) return;
    counts[c] = (counts[c] || 0) + 1;
  });
  const ramos = Object.keys(counts)
    .map(c => ({ cnae: c, descricao: c, total: counts[c] }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 200);
  return { ok: true, ramos };
}

function lerBase_() {
  const s = sh_(SHEET_BASE);
  if (!s) return [];
  const dados = s.getDataRange().getValues();
  const headers = dados.shift();
  return dados.filter(l => l.join('') !== '').map(l => linhaParaObjeto_(headers, l));
}

// Geocodifica em lotes pequenos (não trava a execução, respeita a cota do
// serviço Maps do Apps Script) e devolve o que já tem coordenada até agora.
const LOTE_GEOCODIFICACAO = 25;
const LIMITE_RETORNO_MAPA = 600;

function listarClientesRegiao_(municipio, bairro, segmento, cnae) {
  if (!municipio) return { ok: false, erro: 'município é obrigatório' };
  const sheet = sh_(SHEET_BASE);
  if (!sheet) return { ok: false, erro: 'Base de clientes ainda não foi importada.' };

  const dados = sheet.getDataRange().getValues();
  const headers = dados.shift();
  const idx = {};
  headers.forEach((h, i) => { idx[h] = i; });

  const filtradas = [];
  dados.forEach((linha, i) => {
    const obj = linhaParaObjeto_(headers, linha);
    if ((obj.municipio || '') !== municipio) return;
    if (bairro && (obj.bairro || '') !== bairro) return;
    if (segmento && segmento !== 'Todos' && obj.segmento !== segmento) return;
    if (cnae && String(obj.cnae || '').trim() !== String(cnae).trim()) return;
    filtradas.push({ rowIndex: i + 2, obj });
  });

  const totalRegiao = filtradas.length;
  const pendentes = filtradas.filter(l => !l.obj.geocoded);
  const paraGeocodificar = pendentes.slice(0, LOTE_GEOCODIFICACAO);

  if (paraGeocodificar.length) {
    const geocoder = Maps.newGeocoder().setRegion('BR');
    paraGeocodificar.forEach(l => {
      const endereco = [l.obj.endereco, l.obj.bairro, l.obj.municipio, 'SC', 'Brasil'].filter(Boolean).join(', ');
      try {
        const resultado = geocoder.geocode(endereco);
        if (resultado.status === 'OK' && resultado.results && resultado.results.length) {
          const loc = resultado.results[0].geometry.location;
          l.obj.latitude = loc.lat;
          l.obj.longitude = loc.lng;
          sheet.getRange(l.rowIndex, idx['latitude'] + 1, 1, 3).setValues([[loc.lat, loc.lng, true]]);
        } else {
          sheet.getRange(l.rowIndex, idx['geocoded'] + 1).setValue(true);
        }
      } catch (err) {
        // ignora falha pontual de geocodificação e segue para a próxima
      }
    });
  }

  const comCoordenada = filtradas.filter(l => l.obj.latitude && l.obj.longitude);
  const restantes = filtradas.filter(l => !l.obj.geocoded).length;
  const clientes = comCoordenada.slice(0, LIMITE_RETORNO_MAPA).map(l => l.obj);

  return {
    ok: true,
    clientes,
    total_regiao: totalRegiao,
    exibidos_no_mapa: clientes.length,
    parcial: restantes > 0,
    restantes,
  };
}

/* =========================================================================
   SETUP — migração segura. Roda sempre que quiser, não apaga dados reais
   (Clientes, AGENDA_NOTAS, BASE_CLIENTES). Cria o que estiver faltando.
   ========================================================================= */

function configurarPlanilha() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  let clientes = ss.getSheetByName(SHEET_LEADS);
  if (!clientes) {
    const antiga = ss.getSheetByName(SHEET_LEADS_ANTIGA);
    if (antiga) { antiga.setName(SHEET_LEADS); clientes = antiga; }
    else clientes = ss.insertSheet(SHEET_LEADS);
  }
  if (clientes.getLastRow() === 0) {
    clientes.getRange(1, 1, 1, LEAD_HEADERS.length).setValues([LEAD_HEADERS]);
    clientes.setFrozenRows(1);
    clientes.getRange(1, 1, 1, LEAD_HEADERS.length).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');
  }
  ensureHeaders_(clientes, LEAD_HEADERS);

  let agenda = ss.getSheetByName(SHEET_AGENDA);
  if (!agenda) agenda = ss.insertSheet(SHEET_AGENDA);
  if (agenda.getLastRow() === 0) {
    agenda.getRange(1, 1, 1, AGENDA_HEADERS.length).setValues([AGENDA_HEADERS]);
    agenda.setFrozenRows(1);
    agenda.getRange(1, 1, 1, AGENDA_HEADERS.length).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');
  }

  const base = getOrCriarBase_();
  ensureHeaders_(base, BASE_HEADERS);

  if (!ss.getSheetByName(SHEET_CHECKINS)) {
    const chk = ss.insertSheet(SHEET_CHECKINS);
    chk.appendRow(CHECKIN_HEADERS);
    chk.setFrozenRows(1);
    chk.getRange(1, 1, 1, CHECKIN_HEADERS.length).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');
  }

  const imp1 = ss.getSheetByName(SHEET_IMPORT_BONDMANN) || ss.insertSheet(SHEET_IMPORT_BONDMANN);
  if (imp1.getLastRow() === 0) imp1.appendRow(['cnpj', 'razao_social', 'nome_fantasia', 'tipo_logradouro', 'logradouro', 'numero', 'bairro', 'cep', 'municipio', 'cnae_fiscal_principal', 'porte', 'capital_social']);
  const imp2 = ss.getSheetByName(SHEET_IMPORT_BRANSALES) || ss.insertSheet(SHEET_IMPORT_BRANSALES);
  if (imp2.getLastRow() === 0) imp2.appendRow(['cnpj', 'razao_social', 'nome_fantasia', 'tipo_logradouro', 'logradouro', 'numero', 'bairro', 'cep', 'municipio', 'cnae_fiscal_principal', 'porte', 'capital_social']);

  const def = ss.getSheetByName('Sheet1') || ss.getSheetByName('Página1');
  if (def && ss.getSheets().length > 1) ss.deleteSheet(def);

  Logger.log('Planilha configurada! Vá em Implantar > Gerenciar implantações > editar > Nova versão.');
}
