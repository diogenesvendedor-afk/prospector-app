/**
 * ============================================================
 *  PROSPECTOR CRM — BACKEND ÚNICO (Google Apps Script)
 *  Diogenes Almeida Representações
 * ============================================================
 *  Este script substitui os dois backends antigos (Prospector e
 *  Diário de Bordo) por um só. Ele é MIGRAÇÃO-SEGURA: se você já
 *  tinha a aba LEADS_PROSPECCAO com leads capturados de verdade,
 *  rodar "configurarPlanilha" só RENOMEIA essa aba para "Clientes"
 *  e ACRESCENTA as colunas novas no final — nenhum dado é apagado.
 *
 *  ABAS QUE ESTE SCRIPT CRIA/USA:
 *   - Clientes        (era LEADS_PROSPECCAO — agora CRM completo)
 *   - AGENDA_NOTAS     (igual antes — anotações rápidas)
 *   - Visitas          (novo — agenda semanal de visitas)
 *   - Biblioteca       (novo — rotina diária/semanal)
 *   - Log              (novo — histórico de tarefas concluídas)
 *   - Metricas         (novo — KPIs semanais)
 *   - Config           (novo — data de início do programa etc.)
 *   - Conhecimento     (novo — guias validados de venda)
 *
 *  Rode "configurarPlanilha" UMA VEZ (ou de novo sempre que quiser —
 *  é seguro repetir) depois de colar este código.
 * ============================================================
 */

const SHEET_CLIENTES = 'Clientes';
const SHEET_CLIENTES_ANTIGA = 'LEADS_PROSPECCAO'; // nome usado pela versão anterior do Prospector
const SHEET_NOTAS = 'AGENDA_NOTAS';
const SHEET_VISITAS = 'Visitas';
const SHEET_BIBLIOTECA = 'Biblioteca';
const SHEET_LOG = 'Log';
const SHEET_METRICAS = 'Metricas';
const SHEET_CONFIG = 'Config';
const SHEET_CONHECIMENTO = 'Conhecimento';

const CLIENT_HEADERS = [
  'id', 'data_captura', 'empresa', 'cnpj', 'cnae', 'endereco', 'cidade',
  'telefone', 'email', 'contato', 'latitude', 'longitude', 'status',
  'origem', 'segmento', 'portfolio', 'potencial', 'observacoes', 'vendedor', 'place_id'
];
const NOTE_HEADERS = ['id', 'data', 'hora', 'lead_id', 'titulo', 'nota', 'status'];
const VISIT_HEADERS = ['id', 'date', 'cliente', 'empresa', 'portfolio', 'endereco', 'objetivo', 'status', 'notas'];
const BIBLIOTECA_HEADERS = ['id', 'day', 'pillar', 'portfolio', 'title', 'desc', 'ativo'];
const LOG_HEADERS = ['date', 'taskId', 'done', 'timestamp'];
const METRICAS_HEADERS = ['week', 'visitas', 'propostas', 'fechamentos', 'faturamento', 'obs'];
const CONFIG_HEADERS = ['key', 'value'];
const CONHECIMENTO_HEADERS = ['id', 'pillar', 'portfolio', 'title', 'content', 'tags'];

/* ============================================================
   ENDPOINTS
   ============================================================ */

function doGet(e) {
  try {
    const action = e.parameter.action;
    if (action === 'ping') return responderJson_({ ok: true, mensagem: 'Backend ativo', hora: new Date().toISOString() });
    // bootstrap único — o app busca tudo de uma vez
    return responderJson_({
      ok: true,
      clients: readSheet_(SHEET_CLIENTES),
      notes: readSheet_(SHEET_NOTAS),
      visits: readSheet_(SHEET_VISITAS),
      library: readSheet_(SHEET_BIBLIOTECA).filter(t => t.ativo !== false),
      log: readSheet_(SHEET_LOG),
      metrics: readSheet_(SHEET_METRICAS),
      config: configObj_(),
      knowledge: readSheet_(SHEET_CONHECIMENTO),
    });
  } catch (err) {
    return responderJson_({ ok: false, erro: err.message });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    const p = body.payload || body;
    let result;
    switch (action) {
      case 'addLead':
      case 'addClient': result = adicionarCliente_(p); break;
      case 'updateLead':
      case 'updateClient': result = atualizarCliente_(p); break;
      case 'removeClient': result = deleteRowById_(SHEET_CLIENTES, p.id); break;

      case 'addNote': result = adicionarNota_(p); break;
      case 'updateNote': result = atualizarNota_(p); break;

      case 'addVisit': result = adicionarVisita_(p.visit || p); break;
      case 'updateVisit': result = atualizarCampo_(SHEET_VISITAS, p.id, p.field, p.value); break;
      case 'removeVisit': result = deleteRowById_(SHEET_VISITAS, p.id); break;
      case 'importVisits': result = importarVisitas_(p.rows); break;

      case 'addTask': result = adicionarTarefa_(p.task || p); break;
      case 'removeTask': result = desativarTarefa_(p.id); break;
      case 'toggleTask': result = alternarTarefa_(p.date, p.taskId); break;

      case 'updateMetric': result = atualizarMetrica_(p.week, p.field, p.value); break;
      case 'setConfig': result = definirConfig_(p.key, p.value); break;

      case 'suggestStrategy': result = sugerirEstrategia_(p.clientId); break;

      default: result = { ok: false, erro: 'Ação POST desconhecida: ' + action };
    }
    return responderJson_(result);
  } catch (err) {
    return responderJson_({ ok: false, erro: err.message });
  }
}

function responderJson_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/* ============================================================
   HELPERS GENÉRICOS DE PLANILHA
   ============================================================ */

function sh_(nome) { return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(nome); }

function readSheet_(nome) {
  const s = sh_(nome);
  if (!s) return [];
  const dados = s.getDataRange().getValues();
  const headers = dados.shift();
  return dados.filter(l => l.join('') !== '').map(l => linhaParaObjeto_(headers, l));
}

function linhaParaObjeto_(headers, linha) {
  const obj = {};
  headers.forEach((h, i) => { obj[h] = linha[i]; });
  return obj;
}

function encontrarLinha_(nome, testeFn) {
  const s = sh_(nome);
  const dados = s.getDataRange().getValues();
  const headers = dados[0];
  for (let i = 1; i < dados.length; i++) {
    const obj = linhaParaObjeto_(headers, dados[i]);
    if (testeFn(obj)) return { linha: i + 1, headers, obj };
  }
  return null;
}

function deleteRowById_(nome, id) {
  const achado = encontrarLinha_(nome, o => o.id === id);
  if (!achado) return { ok: false, erro: 'registro não encontrado' };
  sh_(nome).deleteRow(achado.linha);
  return { ok: true };
}

function atualizarCampo_(nome, id, campo, valor) {
  const achado = encontrarLinha_(nome, o => o.id === id);
  if (!achado) return { ok: false, erro: 'registro não encontrado' };
  const col = achado.headers.indexOf(campo) + 1;
  if (col <= 0) return { ok: false, erro: 'campo inválido: ' + campo };
  sh_(nome).getRange(achado.linha, col).setValue(valor);
  return { ok: true };
}

function ensureHeaders_(sheet, desejados) {
  const lastCol = sheet.getLastColumn();
  const existentes = lastCol > 0 ? sheet.getRange(1, 1, 1, lastCol).getValues()[0] : [];
  desejados.forEach(h => {
    if (existentes.indexOf(h) === -1) {
      sheet.getRange(1, sheet.getLastColumn() + 1).setValue(h);
      existentes.push(h);
    }
  });
}

/* ============================================================
   CLIENTES (ex-LEADS_PROSPECCAO — agora CRM completo)
   ============================================================ */

function adicionarCliente_(p) {
  const sheet = sh_(SHEET_CLIENTES);
  const dados = sheet.getDataRange().getValues();
  const headers = dados[0];
  const colPlaceId = headers.indexOf('place_id');
  const colCnpj = headers.indexOf('cnpj');

  // evita duplicar por place_id ou CNPJ — igual ao comportamento antigo
  for (let i = 1; i < dados.length; i++) {
    const mesmoPlace = p.place_id && dados[i][colPlaceId] === p.place_id;
    const mesmoCnpj = p.cnpj && dados[i][colCnpj] === p.cnpj;
    if (mesmoPlace || mesmoCnpj) {
      return { ok: true, duplicado: true, id: dados[i][headers.indexOf('id')], mensagem: 'Cliente já existia, não duplicado.' };
    }
  }

  const id = Utilities.getUuid();
  const novaLinha = headers.map(h => {
    if (h === 'id') return id;
    if (h === 'data_captura') return new Date().toISOString();
    if (h === 'status') return p.status || 'novo';
    if (h === 'portfolio') return p.portfolio || 'ambos';
    if (h === 'potencial') return p.potencial || 'Médio';
    return p[h] !== undefined ? p[h] : '';
  });
  sheet.appendRow(novaLinha);
  return { ok: true, id };
}

function atualizarCliente_(p) {
  if (!p.id) return { ok: false, erro: 'id é obrigatório' };
  const achado = encontrarLinha_(SHEET_CLIENTES, o => o.id === p.id);
  if (!achado) return { ok: false, erro: 'Cliente não encontrado: ' + p.id };
  achado.headers.forEach((h, idx) => {
    if (h !== 'id' && p[h] !== undefined) {
      sh_(SHEET_CLIENTES).getRange(achado.linha, idx + 1).setValue(p[h]);
    }
  });
  return { ok: true };
}

/* ============================================================
   NOTAS RÁPIDAS (agenda)
   ============================================================ */

function adicionarNota_(p) {
  const sheet = sh_(SHEET_NOTAS);
  const id = Utilities.getUuid();
  const agora = new Date();
  const novaLinha = NOTE_HEADERS.map(h => {
    if (h === 'id') return id;
    if (h === 'data') return p.data || Utilities.formatDate(agora, Session.getScriptTimeZone(), 'yyyy-MM-dd');
    if (h === 'hora') return p.hora || Utilities.formatDate(agora, Session.getScriptTimeZone(), 'HH:mm');
    if (h === 'status') return p.status || 'pendente';
    return p[h] !== undefined ? p[h] : '';
  });
  sheet.appendRow(novaLinha);
  return { ok: true, id };
}

function atualizarNota_(p) {
  if (!p.id) return { ok: false, erro: 'id é obrigatório' };
  const achado = encontrarLinha_(SHEET_NOTAS, o => o.id === p.id);
  if (!achado) return { ok: false, erro: 'Nota não encontrada: ' + p.id };
  achado.headers.forEach((h, idx) => {
    if (h !== 'id' && p[h] !== undefined) sh_(SHEET_NOTAS).getRange(achado.linha, idx + 1).setValue(p[h]);
  });
  return { ok: true };
}

/* ============================================================
   AGENDA DE VISITAS
   ============================================================ */

function adicionarVisita_(v) {
  const id = 'v' + new Date().getTime();
  sh_(SHEET_VISITAS).appendRow([id, v.date || '', v.cliente || '', v.empresa || '', v.portfolio || 'ambos', v.endereco || '', v.objetivo || '', v.status || 'Pendente', v.notas || '']);
  return { ok: true, id };
}

function importarVisitas_(rows) {
  const s = sh_(SHEET_VISITAS);
  let count = 0;
  (rows || []).forEach(r => {
    if (!r.cliente && !r.empresa) return;
    const id = 'v' + new Date().getTime() + Math.floor(Math.random() * 1000);
    s.appendRow([id, r.date || '', r.cliente || '', r.empresa || '', r.portfolio || 'ambos', r.endereco || '', r.objetivo || '', 'Pendente', r.notas || '']);
    count++;
  });
  return { ok: true, imported: count };
}

/* ============================================================
   ROTINA (Biblioteca de tarefas + Log)
   ============================================================ */

function adicionarTarefa_(t) {
  const id = 'c' + new Date().getTime();
  sh_(SHEET_BIBLIOTECA).appendRow([id, t.day, t.pillar, t.portfolio, t.title, t.desc, true]);
  return { ok: true, id };
}

function desativarTarefa_(id) {
  const achado = encontrarLinha_(SHEET_BIBLIOTECA, o => o.id === id);
  if (!achado) return { ok: false, erro: 'tarefa não encontrada' };
  const col = achado.headers.indexOf('ativo') + 1;
  sh_(SHEET_BIBLIOTECA).getRange(achado.linha, col).setValue(false);
  return { ok: true };
}

function alternarTarefa_(date, taskId) {
  const achado = encontrarLinha_(SHEET_LOG, o => o.date === date && o.taskId === taskId);
  if (achado) {
    const col = achado.headers.indexOf('done') + 1;
    const novo = !achado.obj.done;
    sh_(SHEET_LOG).getRange(achado.linha, col).setValue(novo);
    return { ok: true, done: novo };
  }
  sh_(SHEET_LOG).appendRow([date, taskId, true, new Date()]);
  return { ok: true, done: true };
}

/* ============================================================
   MÉTRICAS SEMANAIS
   ============================================================ */

function atualizarMetrica_(week, campo, valor) {
  const achado = encontrarLinha_(SHEET_METRICAS, o => o.week === week);
  const s = sh_(SHEET_METRICAS);
  if (achado) {
    const col = achado.headers.indexOf(campo) + 1;
    s.getRange(achado.linha, col).setValue(valor);
    return { ok: true };
  }
  const headers = s.getRange(1, 1, 1, s.getLastColumn()).getValues()[0];
  s.appendRow(headers.map(h => (h === 'week' ? week : h === campo ? valor : '')));
  return { ok: true };
}

/* ============================================================
   CONFIG
   ============================================================ */

function configObj_() {
  const obj = {};
  readSheet_(SHEET_CONFIG).forEach(r => { obj[r.key] = r.value; });
  return obj;
}

function definirConfig_(key, value) {
  const achado = encontrarLinha_(SHEET_CONFIG, o => o.key === key);
  const s = sh_(SHEET_CONFIG);
  if (achado) s.getRange(achado.linha, 2).setValue(value);
  else s.appendRow([key, value]);
  return { ok: true };
}

/* ============================================================
   SUGESTÃO DE ESTRATÉGIA (baseada em regras, sem API externa)
   ============================================================ */

function sugerirEstrategia_(clientId) {
  const cliente = readSheet_(SHEET_CLIENTES).find(c => c.id === clientId);
  if (!cliente) return { ok: false, erro: 'cliente não encontrado' };

  const kb = readSheet_(SHEET_CONHECIMENTO);
  const segTexto = ((cliente.segmento || '') + ' ' + (cliente.cnae || '')).toLowerCase();
  const segPalavras = segTexto.split(/[^a-zà-ú0-9]+/).filter(w => w.length > 2);

  const pontuados = kb.map(k => {
    let score = 0;
    if (k.portfolio === cliente.portfolio || k.portfolio === 'ambos') score += 2;
    const tags = (k.tags || '').toLowerCase().split(',').map(t => t.trim()).filter(Boolean);
    segPalavras.forEach(w => { if (tags.some(t => t.includes(w) || w.includes(t))) score += 1; });
    return Object.assign({}, k, { score });
  });

  let sugestoes = pontuados.filter(k => k.score > 0).sort((a, b) => b.score - a.score).slice(0, 5);
  if (!sugestoes.length) sugestoes = pontuados.filter(k => k.portfolio === cliente.portfolio || k.portfolio === 'ambos').slice(0, 4);

  return { ok: true, client: cliente, suggestions: sugestoes };
}

/* ============================================================
   SETUP — migração segura. Rode sempre que quiser, não apaga
   dados reais (Clientes, Visitas, AGENDA_NOTAS, Log, Metricas,
   Config). Só recria Biblioteca e Conhecimento (dados de template).
   ============================================================ */

function configurarPlanilha() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // 1) Clientes: renomeia a aba antiga se existir, senão cria nova
  let clientes = ss.getSheetByName(SHEET_CLIENTES);
  if (!clientes) {
    const antiga = ss.getSheetByName(SHEET_CLIENTES_ANTIGA);
    if (antiga) { antiga.setName(SHEET_CLIENTES); clientes = antiga; }
    else clientes = ss.insertSheet(SHEET_CLIENTES);
  }
  if (clientes.getLastRow() === 0) {
    clientes.getRange(1, 1, 1, CLIENT_HEADERS.length).setValues([CLIENT_HEADERS]);
  }
  ensureHeaders_(clientes, CLIENT_HEADERS);
  clientes.setFrozenRows(1);
  clientes.getRange(1, 1, 1, clientes.getLastColumn()).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');

  // 2) Notas — mesma aba/estrutura de sempre
  let notas = ss.getSheetByName(SHEET_NOTAS);
  if (!notas) notas = ss.insertSheet(SHEET_NOTAS);
  if (notas.getLastRow() === 0) {
    notas.getRange(1, 1, 1, NOTE_HEADERS.length).setValues([NOTE_HEADERS]);
    notas.setFrozenRows(1);
    notas.getRange(1, 1, 1, NOTE_HEADERS.length).setFontWeight('bold').setBackground('#1A1C1F').setFontColor('#FFFFFF');
  }

  // 3) Visitas
  let visitas = ss.getSheetByName(SHEET_VISITAS);
  if (!visitas) visitas = ss.insertSheet(SHEET_VISITAS);
  if (visitas.getLastRow() === 0) {
    visitas.getRange(1, 1, 1, VISIT_HEADERS.length).setValues([VISIT_HEADERS]);
    visitas.setFrozenRows(1);
  }

  // 4) Biblioteca — sempre recriada (é conteúdo de template)
  const bib = ss.getSheetByName(SHEET_BIBLIOTECA) || ss.insertSheet(SHEET_BIBLIOTECA);
  bib.clear();
  bib.appendRow(BIBLIOTECA_HEADERS);
  DEFAULT_LIBRARY.forEach(t => bib.appendRow([t.id, t.day, t.pillar, t.portfolio, t.title, t.desc, true]));
  bib.setFrozenRows(1);

  // 5) Log
  const log = ss.getSheetByName(SHEET_LOG) || ss.insertSheet(SHEET_LOG);
  if (log.getLastRow() === 0) { log.appendRow(LOG_HEADERS); log.setFrozenRows(1); }

  // 6) Métricas
  const met = ss.getSheetByName(SHEET_METRICAS) || ss.insertSheet(SHEET_METRICAS);
  if (met.getLastRow() === 0) { met.appendRow(METRICAS_HEADERS); met.setFrozenRows(1); }

  // 7) Config
  const cfg = ss.getSheetByName(SHEET_CONFIG) || ss.insertSheet(SHEET_CONFIG);
  if (cfg.getLastRow() === 0) {
    cfg.appendRow(CONFIG_HEADERS);
    cfg.appendRow(['startDate', Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd')]);
    cfg.setFrozenRows(1);
  }

  // 8) Conhecimento — sempre recriado (é conteúdo de template)
  const con = ss.getSheetByName(SHEET_CONHECIMENTO) || ss.insertSheet(SHEET_CONHECIMENTO);
  con.clear();
  con.appendRow(CONHECIMENTO_HEADERS);
  DEFAULT_KNOWLEDGE.forEach(k => con.appendRow([k.id, k.pillar, k.portfolio, k.title, k.content, k.tags]));
  con.setFrozenRows(1);

  const def = ss.getSheetByName('Sheet1') || ss.getSheetByName('Página1');
  if (def && ss.getSheets().length > 1) ss.deleteSheet(def);

  Logger.log('Planilha unificada configurada! Vá em Implantar > Gerenciar implantações > Nova versão.');
}

const DEFAULT_LIBRARY = [
  { id: 't1', day: 1, pillar: 'gestao', portfolio: 'ambos', title: 'Revisar funil da semana', desc: 'Abra a Base de Clientes, revise as oportunidades em aberto e defina a meta de visitas e propostas da semana.' },
  { id: 't2', day: 1, pillar: 'prospeccao', portfolio: 'bondmann', title: 'Prospecção Bondmann', desc: 'Ative a prospecção em rota ou busque manualmente por metal-mecânica/usinagem/serralheria na área de hoje.' },
  { id: 't3', day: 1, pillar: 'prospeccao', portfolio: 'bransales', title: 'Prospecção Bransales', desc: 'Busque frotistas/transportadoras na área de hoje e envie o primeiro contato.' },
  { id: 't4', day: 1, pillar: 'marca', portfolio: 'pessoal', title: 'Planejar conteúdo da semana', desc: 'Defina os temas dos posts/stories da semana para @rdpne_us e o site.' },
  { id: 't5', day: 2, pillar: 'tecnico', portfolio: 'bondmann', title: 'Ficha técnica Bondmann', desc: 'Estude 1 produto do catálogo: aplicação, diferencial técnico e argumento de valor.' },
  { id: 't6', day: 2, pillar: 'negociacao', portfolio: 'bondmann', title: 'Treino de objeção (SPIN)', desc: 'Escolha 1 objeção comum de Bondmann e escreva a resposta usando SPIN Selling.' },
  { id: 't7', day: 2, pillar: 'prospeccao', portfolio: 'bondmann', title: 'Follow-up Bondmann', desc: 'Na Base de Clientes, filtre status "contatado" e retome contato com quem está parado há 3+ dias.' },
  { id: 't8', day: 2, pillar: 'gestao', portfolio: 'ambos', title: 'Atualizar clientes do dia', desc: 'Confira se todos os clientes visitados hoje estão com status e observações atualizados.' },
  { id: 't9', day: 3, pillar: 'marca', portfolio: 'pessoal', title: 'Publicar conteúdo', desc: 'Publique 1 post ou stories com bastidor de trabalho ou dica técnica.' },
  { id: 't10', day: 3, pillar: 'prospeccao', portfolio: 'ambos', title: 'Follow-up de propostas', desc: 'Revise clientes com status "qualificado" sem contato recente.' },
  { id: 't11', day: 3, pillar: 'marca', portfolio: 'pessoal', title: 'Interação estratégica', desc: 'Comente ou interaja com 5 perfis de clientes ou parceiros do setor.' },
  { id: 't12', day: 3, pillar: 'gestao', portfolio: 'ambos', title: 'Sincronizar planilha', desc: 'Use "Exportar & Sincronizar" no menu para garantir que a planilha está 100% atualizada.' },
  { id: 't13', day: 4, pillar: 'tecnico', portfolio: 'bransales', title: 'Linha de pneus Bransales', desc: 'Estude 1 linha de pneus: aplicação, durabilidade e argumento de custo por km rodado.' },
  { id: 't14', day: 4, pillar: 'negociacao', portfolio: 'bransales', title: 'Simulação Challenger Sale', desc: 'Simule um fechamento real usando a técnica Challenger Sale para um cliente do funil.' },
  { id: 't15', day: 4, pillar: 'prospeccao', portfolio: 'bransales', title: 'Follow-up Bransales', desc: 'Retome contato com leads Bransales parados há mais de 3 dias.' },
  { id: 't16', day: 4, pillar: 'gestao', portfolio: 'ambos', title: 'Atualizar clientes do dia', desc: 'Confira se todos os clientes visitados hoje estão com status e observações atualizados.' },
  { id: 't17', day: 5, pillar: 'negociacao', portfolio: 'ambos', title: 'Revisão de propostas em aberto', desc: 'Revise todas as oportunidades em aberto e defina a próxima ação de cada uma.' },
  { id: 't18', day: 5, pillar: 'negociacao', portfolio: 'ambos', title: 'Pós-mortem de negociação', desc: 'Escolha a negociação mais difícil da semana e escreva o que faria diferente.' },
  { id: 't19', day: 5, pillar: 'gestao', portfolio: 'ambos', title: 'Taxa de conversão da semana', desc: 'Calcule visitas → propostas → fechamentos e registre na aba Métricas.' },
  { id: 't20', day: 5, pillar: 'marca', portfolio: 'pessoal', title: 'Pedido de indicação', desc: 'Peça 1 indicação ou depoimento a um cliente satisfeito.' },
  { id: 't21', day: 6, pillar: 'gestao', portfolio: 'ambos', title: 'Revisão semanal completa', desc: 'Revise KPIs, funil e defina as metas da próxima semana.' },
  { id: 't22', day: 6, pillar: 'marca', portfolio: 'pessoal', title: 'Conteúdo de autoridade', desc: 'Planeje ou grave um vídeo curto, artigo ou case para publicar na semana seguinte.' },
  { id: 't23', day: 6, pillar: 'tecnico', portfolio: 'ambos', title: 'Leitura técnica/setorial', desc: 'Leia 1 material sobre o setor metal-mecânico ou de transporte/logística.' },
  { id: 't24', day: 0, pillar: 'marca', portfolio: 'pessoal', title: 'Planejamento leve', desc: 'Revise a semana e ajuste a agenda da próxima. Opcional, sem pressão.' },
];

const DEFAULT_KNOWLEDGE = [
  { id: 'k1', pillar: 'negociacao', portfolio: 'bondmann', title: 'SPIN Selling aplicado a produtos químicos industriais',
    content: 'Situação: entenda o processo produtivo atual. Problema: pergunte sobre falhas, retrabalho, paradas de máquina. Implicação: quantifique o custo dessas falhas. Necessidade de solução: leve o cliente a verbalizar o ganho de resolver isso — só então apresente o produto Bondmann.',
    tags: 'metal-mecanica,usinagem,serralheria,industria,quimica' },
  { id: 'k2', pillar: 'negociacao', portfolio: 'bransales', title: 'Challenger Sale para frotistas e transportadoras',
    content: 'Ensine algo novo (ex: como durabilidade muda o custo por km rodado). Adapte ao que mais importa (uptime, segurança, custo). Assuma o controle levando a conversa para o TCO da frota, não para desconto.',
    tags: 'frota,transportadora,logistica,transporte' },
  { id: 'k3', pillar: 'marca', portfolio: 'pessoal', title: 'Checklist de marca pessoal para ser procurado',
    content: '1) LinkedIn com headline clara dos dois portfólios. 2) Postar 1x/semana conteúdo técnico de verdade. 3) Responder rápido. 4) Pedir depoimento a cada fechamento importante. 5) Site sempre atualizado com cases reais.',
    tags: 'geral' },
  { id: 'k4', pillar: 'tecnico', portfolio: 'bondmann', title: 'Como argumentar valor técnico Bondmann',
    content: 'Foque em custo total: menos paradas de manutenção, menos refugo, conformidade com normas. Traga exemplo numérico sempre que possível.',
    tags: 'metal-mecanica,quimica,industria' },
  { id: 'k5', pillar: 'tecnico', portfolio: 'bransales', title: 'Como argumentar valor técnico Bransales',
    content: 'Traduza tudo para custo por km rodado. Fale de uptime da frota, menos trocas por ano, menos veículos parados na oficina.',
    tags: 'frota,transportadora,logistica' },
  { id: 'k6', pillar: 'prospeccao', portfolio: 'ambos', title: 'Roteiro de primeiro contato (cold approach)',
    content: 'Abra citando algo específico da empresa. Faça 1 pergunta de diagnóstico real. Não venda no primeiro contato — o objetivo é agendar uma conversa mais longa.',
    tags: 'geral' },
  { id: 'k7', pillar: 'negociacao', portfolio: 'ambos', title: 'Como responder objeção de preço',
    content: 'Não entre em disputa de desconto. Reancore no custo total. Pergunte "comparado com o quê?" antes de reposicionar o valor.',
    tags: 'geral' },
  { id: 'k8', pillar: 'gestao', portfolio: 'ambos', title: 'Como priorizar a Base de Clientes da semana',
    content: 'Classifique por potencial (alto/médio/baixo) e proximidade do fechamento. Priorize sempre alto potencial + quente primeiro.',
    tags: 'geral' },
  { id: 'k9', pillar: 'marca', portfolio: 'pessoal', title: 'Pauta de conteúdo semanal',
    content: 'Alterne: bastidor de trabalho, dica técnica curta, case real (com autorização), opinião/posicionamento sobre o setor.',
    tags: 'geral' },
  { id: 'k10', pillar: 'prospeccao', portfolio: 'bondmann', title: 'Como identificar bons prospects Bondmann via CNAE',
    content: 'Priorize CNAEs de metalurgia, usinagem, serralheria e metal-mecânica. Sinais de potencial: porte médio/grande, atividade fabril contínua.',
    tags: 'metal-mecanica,cnae,usinagem,serralheria' },
  { id: 'k11', pillar: 'prospeccao', portfolio: 'bransales', title: 'Como identificar bons prospects Bransales via CNAE',
    content: 'Priorize CNAEs de transporte rodoviário de carga, logística e locação de veículos. Sinais de potencial: frota própria, operação regional/nacional.',
    tags: 'transporte,logistica,cnae,frota' },
  { id: 'k12', pillar: 'negociacao', portfolio: 'pessoal', title: 'Como pedir indicação sem parecer forçado',
    content: 'Melhor momento: logo após entrega bem-sucedida ou elogio espontâneo. Peça de forma específica, não genérica.',
    tags: 'geral' },
];
