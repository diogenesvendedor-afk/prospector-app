# Prospector CRM — guia de atualização (união dos dois apps)

Este pacote substitui o Prospector antigo E o Diário de Bordo por um único
app. **Seus leads capturados em campo não são perdidos** — a migração é
automática e segura.

## O que mudou

- Um app só, um menu só (☰), uma planilha só.
- A aba `LEADS_PROSPECCAO` vira `Clientes` (renomeada, dados preservados) e
  ganha campos novos: cidade, contato, portfólio, potencial.
- Categorias de status atualizadas para o seu vocabulário real: **Prospecto,
  Contatado, Qualificado, Ativo, N Fidelizado, Inativo, Conta KAM**.
- Menu novo: **Hoje** (bússola diária), **Base de Clientes** (CRM completo,
  substitui "Leads"), **Agenda** (agora com Notas *e* Visitas), **Rotina
  semanal**, **Métricas**, **Guia de vendas**, **Programa**.
- "Exportar leads" virou **"Exportar & Sincronizar"** — antes de gerar o CSV,
  o app garante que tudo que está salvo no aparelho já foi enviado pra
  planilha.
- Na **Base de Clientes**: filtro por ramo/segmento, portfólio e status, com
  botão **"Mostrar filtro no mapa"** — só os clientes filtrados aparecem como
  marcador, e **"Mostrar todos"** volta a exibir tudo.
- Editar um cliente (qualquer campo) agora sempre grava direto na planilha.

## Passo 1 — Atualizar o backend (Apps Script)

1. Abra a planilha que o Prospector já usa hoje.
2. Extensões > Apps Script.
3. Apague todo o conteúdo do editor e cole o `Code.gs` novo por cima.
4. No seletor de funções, escolha **configurarPlanilha** e clique em
   **Executar**. Autorize se pedir.
   - Isso renomeia `LEADS_PROSPECCAO` para `Clientes` automaticamente e
     acrescenta as colunas novas (cidade, contato, portfolio, potencial) —
     **nenhuma linha existente é apagada ou movida**.
   - Cria as abas novas: `Visitas`, `Biblioteca`, `Log`, `Metricas`,
     `Config`, `Conhecimento`.
   - `AGENDA_NOTAS` continua exatamente como estava.
5. Vá em **Implantar > Gerenciar implantações**, clique no lápis, escolha
   **Nova versão** e implante. A URL do backend continua a mesma — não
   precisa reconfigurar no app.

## Passo 2 — Atualizar o app (GitHub Pages)

No repositório do Prospector no GitHub: **Add file > Upload files**, arraste
por cima os arquivos deste pacote (`index.html`, `manifest.json`,
`service-worker.js`, e a pasta `icons/` com os dois ícones) e clique em
**Commit changes**. Substitui os antigos automaticamente.

## Passo 3 — Abrir no celular

Abra o app normalmente. Como o `service-worker.js` já usa a estratégia
"network-first", ele deve atualizar sozinho em poucos segundos. Se a tela
continuar com a versão antiga, limpe o cache do site (Configurações do
navegador > Privacidade > Limpar dados de navegação, filtrando pelo domínio
do GitHub Pages) e reabra.

Suas configurações salvas (chave do Maps, URL do backend, nome, nichos)
continuam as mesmas — não precisa preencher onboarding de novo.

## Como usar as novidades

**Base de Clientes** — abra pelo menu ☰. Busque por nome, filtre por ramo,
portfólio ou status. Toque em **"Mostrar filtro no mapa"** para que só esses
clientes apareçam como marcador (ótimo antes de sair pra rua num dia focado
num nicho específico); **"Mostrar todos"** volta ao normal. Toque em
qualquer cliente (na lista ou no marcador do mapa) para editar todos os
campos, pedir uma **sugestão de estratégia** (baseada nos guias da aba
Guia), ou excluir.

**Agenda > Visitas** — cole sua planilha de visitas da semana em
**Importar** (Data, Cliente, Empresa, Portfólio, Endereço, Objetivo, sem
cabeçalho) ou cadastre uma a uma em **+ Nova**. As de hoje aparecem
automaticamente na aba **Hoje**.

**Hoje** — sua bússola do dia: rotina da semana + visitas agendadas para
hoje, tudo num só lugar, com um medidor de % concluído e sequência de dias
seguidos.

**Rotina semanal** — as tarefas recorrentes (equivalente à antiga
"biblioteca" do Diário de Bordo). Edite/adicione à vontade.

**Guia de vendas** — os tópicos validados (SPIN, Challenger, como priorizar
o funil etc.), filtráveis por portfólio.

**Métricas** — KPIs semanais com histórico visual.

**Programa** — mostra em que fase você está (Fundação/Expansão/Autoridade).

## Se algo não migrar como esperado

Se por algum motivo a aba `LEADS_PROSPECCAO` não for encontrada (por
exemplo, se o nome foi alterado manualmente antes), o script cria uma aba
`Clientes` nova e vazia — nesse caso, me avise que te ajudo a copiar os
dados antigos manualmente, linha por linha, sem perder nada.
